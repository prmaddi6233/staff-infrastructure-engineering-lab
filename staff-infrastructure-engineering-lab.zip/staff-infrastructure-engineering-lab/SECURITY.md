# Security
This is an independent public reference project. Do not probe or test CMB or any third-party infrastructure. Never commit secrets, proprietary configuration or real customer data. Any future cloud deployment must use isolated accounts, least privilege, cost controls and approval for destructive actions.
