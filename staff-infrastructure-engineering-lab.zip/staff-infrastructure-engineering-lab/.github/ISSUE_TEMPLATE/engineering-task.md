---
name: Engineering task
about: Evidence-based engineering improvement
---
## Business risk / problem
## Known evidence vs assumptions
## Design alternatives and trade-offs
## Blast radius, security, cost and rollback
## Implementation steps
## Testable acceptance criteria
## Evidence links
