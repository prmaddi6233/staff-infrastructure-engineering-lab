## Problem / user impact

## Evidence and assumptions

## Changes

## Alternatives and trade-offs

## Security, reliability, cost and blast radius

## Validation performed (paste actual commands/results)

## Rollback and cleanup

## Status
- [ ] Documentation only
- [ ] Implemented
- [ ] Tested with reproducible evidence
