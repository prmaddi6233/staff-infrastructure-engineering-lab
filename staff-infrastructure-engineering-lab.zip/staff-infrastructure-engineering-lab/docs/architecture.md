# Hypothetical reference architecture (not CMB infrastructure)

```mermaid
flowchart TD
  U[Mobile clients] --> E[Edge and WAF]
  E --> K[Multi-AZ Kubernetes APIs]
  K --> P[(Managed PostgreSQL)]
  K --> R[(Redis)]
  K --> Q[Queue]
  Q --> W[Async recommendation workers]
  P --> B[Isolated recovery account / vault]
  B --> X[Recovery validation environment]
  K --> O[SLIs, traces, metrics, logs]
  W --> O
  I[Terraform + CI policy gates] --> K
```

## Decisions to validate
- Multi-AZ is not equivalent to multi-region recovery; assess consistency, cost and RTO/RPO first.
- Separate batch/recommendation workers from latency-sensitive APIs with quotas and queue backpressure.
- Validate KMS, IAM and resource-specific AWS Backup support before assuming cross-account restore works.
- Evaluate HPA + managed node groups against HPA + Karpenter with churn, availability and cost trade-offs.
- Use synthetic traffic and load tests before tuning requests, limits or autoscaling.
