# Coffee Meets Bagel — independent engineering perspective

## Scope and evidence
This document supports a Staff Infrastructure Engineer application. It is an independent proposal, not a statement of CMB's current architecture or security posture. Public reports described a destructive incident and service outage in 2023; this is **historical context only**, and any current deficiencies are unknown. Verify and cite primary reporting before making a specific public factual claim.

## Hypothetical consumer-app critical journeys
Login, discovery, matching, messaging. These are examples for discussion, not a verified dependency map. The reference architecture assumes AWS, Kubernetes, managed PostgreSQL, Redis, asynchronous workers and observability; specific CMB deployments are unknown.

### Priority 0 — Recovery confidence
Question: can a synthetic customer journey be restored after workload-account administrative compromise? Evaluate isolated recovery permissions, backup retention/immutability, encryption-key access, infrastructure rebuild and dependency ordering. Compare same-account backup, cross-account backup and cross-region copies. Run an authorized recovery game day; measure actual RTO and RPO.

### Priority 1 — Customer-focused reliability
Define SLIs and SLOs with product owners for critical journeys. Test dependency timeouts, graceful degradation, rollout rollback, PDBs, HPA, node capacity and zone failures. Alert on burn rates and user impact, not just CPU utilization.

### Priority 2 — Sustainable scaling
Attribute cost by service and workload; validate EKS capacity, storage, network egress and database usage. Use read-only discovery, canaries, rollback and explicit approval for remediation. Measure cost per successful request alongside reliability.

## Staff-level discovery questions
- Which user journeys have the highest incident severity and what are their current SLOs?
- What RTO/RPO has been demonstrated in the last restore exercise?
- Which failure modes or production changes create the largest blast radius?
- Who owns deployment safety and service reliability across platform and application teams?
- Which costs are unattributed and what workload utilization signals are trusted?

## Ethical boundaries
No unauthorized scanning, exploitation or claims of vulnerabilities. No proprietary code, internal employer details or secrets. All examples are synthetic and explicitly labeled.
