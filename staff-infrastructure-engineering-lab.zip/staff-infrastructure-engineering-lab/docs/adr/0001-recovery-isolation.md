# ADR-001: Isolated recovery architecture
**Status: Proposed**

## Context
A destructive actor with workload-account access may delete primary data and accessible backups. A backup existing does not prove it can be restored.

## Decision
Evaluate cross-account recovery isolation, independent recovery operators, restricted copy and deletion permissions, retention enforcement, KMS recoverability, IaC rebuild and dependency-aware restoration.

## Alternatives
1. Same-account backups: simpler and cheaper but shared administrative blast radius.
2. Cross-account copies: stronger separation, more IAM/KMS and operational complexity.
3. Cross-region recovery: geographical isolation, higher cost and potential consistency concerns.

## Validation
In a synthetic environment, demonstrate inability of the workload operator to delete isolated recovery points and independent recovery of a customer-like transaction. Capture actual RTO/RPO and costs. Verify supported resource-specific capabilities rather than assuming vault lock applies uniformly.
