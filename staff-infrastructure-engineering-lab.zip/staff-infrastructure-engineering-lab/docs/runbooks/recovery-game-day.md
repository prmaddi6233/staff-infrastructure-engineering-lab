# Recovery game day — synthetic test only

1. Confirm approved isolated test accounts, budget alert, synthetic dataset and teardown owner.
2. Record target RTO/RPO, selected recovery point and start time.
3. Simulate workload-account loss without touching production resources.
4. Restore database/storage to isolated environment with independent recovery credentials.
5. Rebuild network, access and services from versioned infrastructure definitions.
6. Validate synthetic login and messaging transactions, checksums and dependency health.
7. Record measured RTO/RPO, restore job IDs, KMS outcomes, failures and costs.
8. Tear down after approval; create follow-up issues for any missed objectives.
