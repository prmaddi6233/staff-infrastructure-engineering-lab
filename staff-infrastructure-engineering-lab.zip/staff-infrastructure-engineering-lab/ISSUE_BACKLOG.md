# GitHub issue backlog — ready to create after repository permissions are granted

> All tasks are **planned**. Do not mark complete without reproducible evidence.

## P0 — Establish truthful CMB context and risk boundaries
- **Issue 1: Verify public evidence and separate CMB facts from assumptions**. Acceptance: dated primary references, explicit unknowns, no assertions of present vulnerabilities.
- **Issue 2: Model destructive-event recovery boundaries**. Acceptance: threat model for compromised workload credentials, backup deletion, KMS access and independent restore.
- **Issue 3: Build synthetic restore proof of concept**. Acceptance: repeatable isolated recovery with timestamped RTO/RPO evidence, no production data.
- **Issue 4: Define customer-journey SLO reference workload**. Acceptance: synthetic login/matching/messaging flows, RED metrics and burn-rate alerts.

## P1 — Demonstrate implementation quality
- **Issue 5: Kubernetes resilience and autoscaling lab**. Acceptance: reproducible load, HPA/PDB/node-drain test, documented failure modes.
- **Issue 6: Add IaC/CI quality gates**. Acceptance: fmt, validate, static security checks, tests, no long-lived AWS credentials, protected review.
- **Issue 7: FinOps read-only recommendation model**. Acceptance: deterministic fixtures, cost/performance trade-off, no default mutation.
- **Issue 8: Data dependency failure drill**. Acceptance: PostgreSQL/Redis failure simulation, graceful degradation and recovery proof.

## P2 — Staff-level adoption and portfolio polish
- **Issue 9: ADRs comparing recovery, rollout and scaling alternatives**. Acceptance: rationale, rejected options, cost and rollback.
- **Issue 10: Publish measured outcomes and demo walkthrough**. Acceptance: evidence linked, clear implemented/tested/planned labels.
- **Issue 11: 30/60/90-day engineering adoption plan**. Acceptance: stakeholder discovery, milestones, ownership and decision gates.
- **Issue 12: Add case study to personal portfolio and application email**. Acceptance: public links checked; no implied CMB endorsement.
