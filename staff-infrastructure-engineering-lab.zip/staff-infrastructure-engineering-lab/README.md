# Staff Infrastructure Engineering Lab

**Independent Staff Infrastructure Engineering case study — AWS, Kubernetes, disaster recovery, and FinOps.**

> This is a personal reference architecture inspired by the Coffee Meets Bagel Senior/Staff Infrastructure Engineer role. It is **not** an audit of CMB, does not use its internal systems, and does not assert that historical issues remain unresolved.

## Engineering questions
1. Can critical customer journeys recover after destructive deletion or account compromise?
2. Can Kubernetes and data dependencies meet measurable customer-facing SLOs under failure?
3. Can infrastructure cost be optimized without weakening reliability or recovery?

## Read the case study
- [CMB-specific engineering brief](docs/cmb-case-study.md)
- [Hypothetical reference architecture](docs/architecture.md)
- [30/60/90-day implementation plan](ROADMAP.md)
- [Recovery isolation ADR](docs/adr/0001-recovery-isolation.md)
- [Recovery game-day runbook](docs/runbooks/recovery-game-day.md)

## Related public work
- [AWS platform control plane](https://github.com/prmaddi6233/aws-platform-control-plane)
- [Cloud FinOps agent](https://github.com/prmaddi6233/cloud-finops-agent)
- [EKS cost governance toolkit](https://github.com/prmaddi6233/eks-cost-governance-toolkit)

## Evidence and status
**Planning stage.** No live AWS deployments, restoration tests, measured RTO/RPO, or verified savings from this repository yet. Planned tasks are tracked in ROADMAP.md. All implementation must use synthetic data and authorized test infrastructure. No probing of CMB infrastructure.
