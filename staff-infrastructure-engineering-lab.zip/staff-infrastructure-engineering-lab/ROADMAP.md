# Roadmap — planned work, not implemented

| Priority | GitHub issue | Acceptance evidence |
|---|---|---|
| P0 | Verify public sources and assumptions | Primary citations, dates, unknowns documented |
| P0 | Threat-model destructive-event recovery | Threat model, IAM/KMS boundary review, ADR |
| P0 | Build isolated synthetic backup/restore PoC | Repeatable logs, actual RTO/RPO, teardown |
| P0 | Create customer-journey SLO demo | Synthetic load, dashboard, burn-rate alerts |
| P1 | Kubernetes failure/recovery lab | PDB/HPA/node failure test results |
| P1 | Add IaC and CI security gates | Passing automated tests and policy checks |
| P1 | Implement read-only FinOps assessment | Deterministic fixtures, no write permissions |
| P2 | Cost-aware scaling and unit economics | Load/cost measurement methodology |

## First 30 days
Discovery, service inventory, critical journeys, baseline incident data, current controls, architecture decisions and objectives. No predetermined redesign.

## Days 31–60
Pilot a synthetic restore game day, one SLO implementation, safe delivery guardrails and read-only cost attribution. Publish reproducible evidence.

## Days 61–90
Evaluate pilot outcomes, improve shared standards, establish review/ownership cadence and expand only validated patterns.

## Release gates
Do not claim a feature is implemented until code is merged; do not claim tested until CI or game-day evidence exists; do not claim savings without comparable baseline and measurement.
