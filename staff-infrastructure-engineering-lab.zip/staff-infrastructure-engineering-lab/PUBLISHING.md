# Publishing instructions
The GitHub connector currently provides read-only access to `prmaddi6233` and cannot create repositories. Do not treat this bundle as published.

1. Create public repository `prmaddi6233/staff-infrastructure-engineering-lab` using https://github.com/new. Leave README/license initialization disabled.
2. Unzip the bundle, then from its root:

```bash
git init -b main
git add .
git commit -m "docs: initial independent Staff infrastructure case study"
git remote add origin git@github.com:prmaddi6233/staff-infrastructure-engineering-lab.git
git push -u origin main
```

3. For a reviewable PR instead, initialize `main` with a short README first, create `feature/architecture-foundation`, commit the case-study files on that branch, push it and open a PR.
4. Create issues using ISSUE_BACKLOG.md; do not claim they exist before creating them.
5. Run GitHub Actions and verify checks before sharing.
